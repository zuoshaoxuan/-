﻿# Host: localhost  (Version: 5.6.10)
# Date: 2020-08-11 14:04:56
# Generator: MySQL-Front 5.3  (Build 2.42)

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE */;
/*!40101 SET SQL_MODE='NO_ENGINE_SUBSTITUTION' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES */;
/*!40103 SET SQL_NOTES='ON' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;

DROP DATABASE IF EXISTS `cloud`;
CREATE DATABASE `cloud` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `cloud`;

#
# Source for table "admin"
#

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '用户名',
  `password` varchar(255) NOT NULL DEFAULT '' COMMENT '密码',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='管理员';

#
# Data for table "admin"
#

INSERT INTO `admin` VALUES (1,'zhangsan','123'),(2,'lisi','123');

#
# Source for table "e_user"
#

DROP TABLE IF EXISTS `e_user`;
CREATE TABLE `e_user` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `bossname` varchar(20) NOT NULL DEFAULT '' COMMENT '企业名称',
  `bosslist` varchar(20) NOT NULL DEFAULT '' COMMENT '行业类型',
  `peoplenumber` varchar(255) NOT NULL DEFAULT '' COMMENT '人员规模',
  `yyfilename` varchar(255) NOT NULL DEFAULT '' COMMENT '营业执照',
  `sfzfilename` varchar(255) NOT NULL DEFAULT '' COMMENT '法人身份证',
  `bossusername` varchar(255) NOT NULL DEFAULT '' COMMENT '公司用户名',
  `bosspassword` varchar(255) NOT NULL DEFAULT '' COMMENT '密码',
  `bossphone` varchar(255) NOT NULL DEFAULT '' COMMENT '联系电话',
  `bossaddress` varchar(255) NOT NULL DEFAULT '' COMMENT '公司地址',
  `bossintro` varchar(255) NOT NULL DEFAULT '' COMMENT '公司简介',
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

#
# Data for table "e_user"
#

INSERT INTO `e_user` VALUES (1,'腾讯','木材','7','222','222','wanger','123','123456789','安徽','诚信'),(2,'阿里巴巴','金属','5','111','111','mazi','123','123456','北京','便宜'),(3,'哎呦','农业','1','aa','dd','aab','123','2333','2323','1441414');

#
# Source for table "order"
#

DROP TABLE IF EXISTS `order`;
CREATE TABLE `order` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `boss_id` int(11) NOT NULL DEFAULT '0',
  `p_name` varchar(255) NOT NULL DEFAULT '',
  `e_name` varchar(255) DEFAULT NULL,
  `price` int(11) DEFAULT '0',
  `createtime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '创建时间',
  `paytime` datetime DEFAULT NULL COMMENT '支付时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='订单';

#
# Data for table "order"
#

INSERT INTO `order` VALUES (1,1,0,'wang','wanger',200,'1882-08-22 00:00:00','1899-12-30 00:00:00'),(2,2,0,'wu','mazi',500,'2011-10-23 00:00:00','2009-10-20 00:00:00');

#
# Source for table "p_user"
#

DROP TABLE IF EXISTS `p_user`;
CREATE TABLE `p_user` (
  `userId` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` varchar(20) NOT NULL DEFAULT '' COMMENT '用户名',
  `password` varchar(20) NOT NULL DEFAULT '' COMMENT '密码',
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT '姓名',
  `age` varchar(20) NOT NULL DEFAULT '' COMMENT '年龄',
  `sex` varchar(20) NOT NULL DEFAULT '' COMMENT '性别',
  `phone` varchar(20) NOT NULL DEFAULT '' COMMENT '电话',
  `email` varchar(20) NOT NULL DEFAULT '' COMMENT '邮箱',
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

#
# Data for table "p_user"
#

INSERT INTO `p_user` VALUES (1,'wu','123','gg','22','man','123456000','1245@qq.com'),(2,'wang','123','mm','21','women','789789789','5555@qq.com');

#
# Source for table "resource"
#

DROP TABLE IF EXISTS `resource`;
CREATE TABLE `resource` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '名称',
  `type` varchar(255) NOT NULL DEFAULT '' COMMENT '类型',
  `model` varchar(255) NOT NULL DEFAULT '' COMMENT '型号',
  `address` varchar(255) DEFAULT '' COMMENT '所在地址',
  `phone` varchar(255) NOT NULL DEFAULT '' COMMENT '联系方式',
  `intro` varchar(255) NOT NULL DEFAULT '' COMMENT '简介',
  `providername` varchar(20) NOT NULL DEFAULT '' COMMENT '提供者',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

#
# Data for table "resource"
#

INSERT INTO `resource` VALUES (2,'a','aaa','dd','aa','dd','dd','wanger');

#
# Source for table "task"
#

DROP TABLE IF EXISTS `task`;
CREATE TABLE `task` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '任务名',
  `demander` varchar(255) NOT NULL DEFAULT '' COMMENT '需求者',
  `info` varchar(255) DEFAULT NULL COMMENT '简介',
  `type` varchar(255) NOT NULL DEFAULT '' COMMENT '类型',
  `ftype` varchar(255) DEFAULT NULL COMMENT '功能类型',
  `address` varchar(255) DEFAULT '' COMMENT '所在位置',
  `phone` varchar(255) DEFAULT NULL COMMENT '联系方式',
  `evaluate` varchar(255) DEFAULT NULL COMMENT '客户评价',
  `price` int(11) DEFAULT '0' COMMENT '价格标准',
  `checktime` varchar(255) NOT NULL DEFAULT '未审核' COMMENT '审核时间',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

#
# Data for table "task"
#

INSERT INTO `task` VALUES (6,'aa','wu','aa','加工制造','aa','1','1','1',1,'驳回'),(7,'ada','wu','dad','加工制造','dad','da','da','da',2,'2020-06-18 审核通过'),(8,'gf','wu','gfg','加工制造','gf','中国安徽巢湖','055188305673','ffff',3,'驳回');

/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
