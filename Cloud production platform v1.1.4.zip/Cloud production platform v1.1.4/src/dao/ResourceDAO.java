package dao;

import java.util.List;

import bean.Resource;


public interface ResourceDAO {
	//��ԴDAO�ӿ�
	public List<Resource> Showresource(String sql);

}
