package dao;

import java.util.List;

import bean.Task;

public interface TaskDAO {
	//����DAO�ӿ�
	public List<Task> Showtask(String sql);	
	
}
