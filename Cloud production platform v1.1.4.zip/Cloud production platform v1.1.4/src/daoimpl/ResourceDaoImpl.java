package daoimpl;

import java.util.ArrayList;
import java.util.List;

import dao.ResourceDAO;
import bean.Resource;


import com.dbconn.DBAccess;

public class ResourceDaoImpl implements ResourceDAO {

	@Override
	public List<Resource> Showresource(String message) {
		List<Resource> list_resource = new ArrayList<Resource>();
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = 
				"select * from resource where name like'%"
				+ message + 
				"%' or type like'%"
				+ message + 
				"%' or model like'%"
				+ message + 
				"%' or address like'%"
				+ message + 
				"%' or phone like'%"
				+ message + 
				"%' or intro like'%"
				+ message + 
				"%' or providername like'%"
				+ message + 
				"%'";
			db.query(sql);
			try {
				int i=0;
				while (db.next()) {
					Resource resource= new Resource();
					resource.setId(db.getRs().getInt(1));
					resource.setName(db.getRs().getString(2));
					resource.setType(db.getRs().getString(3));
					resource.setModel(db.getRs().getString(4));
					resource.setAddress(db.getRs().getString(5));
					resource.setPhone(db.getRs().getString(6));
					resource.setIntro(db.getRs().getString(7));
					resource.setProviderName(db.getRs().getString(8));						
					list_resource.add(resource);						
				}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		return list_resource;
	}




}
