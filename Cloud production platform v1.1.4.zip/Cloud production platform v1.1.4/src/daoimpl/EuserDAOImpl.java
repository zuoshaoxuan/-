package daoimpl;

import java.util.ArrayList;
import java.util.List;

import com.dbconn.DBAccess;

import bean.Euser;
import bean.Order;
import bean.Resource;
import bean.Task;
import dao.EuserDAO;

public class EuserDAOImpl implements EuserDAO {

	@Override
	public Euser login(String username, String password) {
		// TODO Auto-generated method stub
		
		Euser euser = new Euser();
		boolean flag = false;	//��־λ��false����δ�ҵ�
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = 
				"select * from e_user where bossusername='"
				+ username + 
				"' and bosspassword='"
				+ password + 
				"'";
			db.query(sql);
			if (db.next()) {
				flag = true;	//�ҵ�ƥ����û���������
				try {
					euser.setUserId(db.getRs().getInt(1));
					euser.setBossname(db.getRs().getString(2));
					euser.setBosslist(db.getRs().getString(3));
					euser.setPeoplenumber(db.getRs().getString(4));
					euser.setYyfilename(db.getRs().getString(5));
					euser.setSfzfilename(db.getRs().getString(6));
					euser.setBossusername(db.getRs().getString(7));
					euser.setBosspassword(db.getRs().getString(8));
					euser.setBossphone(db.getRs().getString(9));
					euser.setBossaddress(db.getRs().getString(10));
					euser.setBossintro(db.getRs().getString(11));
				}
				catch(Exception e) {
					e.printStackTrace();
				}
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		
		if(flag == true) {
			return euser;
		}
		else {
			return null;
		}
	}

	@Override
	public boolean register(Euser euser) {
		// TODO Auto-generated method stub

		boolean flag = false;	//��־λ��false����δ�ɹ�
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = 
				"insert into "
				+"e_user(bossname, bosslist, peoplenumber, yyfilename, sfzfilename, bossusername, bosspassword, bossphone, bossaddress, bossintro) "
				+"values('"
				+euser.getBossname()+"', '"
				+euser.getBosslist()+"', '"
				+euser.getPeoplenumber()+"', '"
				+euser.getYyfilename()+"', '"
				+euser.getSfzfilename()+"', '"
				+euser.getBossusername()+"', '"
				+euser.getBosspassword()+"', '"
				+euser.getBossphone()+"', '"
				+euser.getBossaddress()+"', '"
				+euser.getBossintro()+"')";
			if (db.update(sql) > 0) {
				flag = true;	//�������ݿ�ɹ�
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		
		return flag;
	}

	@Override
	public List<Resource> showResource(String name) {
		// TODO Auto-generated method stub
		List<Resource> list_resource = new ArrayList<Resource>();
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = 
				"select * from resource where providername='" + name + "'";
			db.query(sql);
			try {
				int i=0;
				while (db.next()) {
					Resource resource= new Resource();
					resource.setId(db.getRs().getInt(1));
					resource.setName(db.getRs().getString(2));
					resource.setType(db.getRs().getString(3));
					resource.setModel(db.getRs().getString(4));
					resource.setAddress(db.getRs().getString(5));
					resource.setPhone(db.getRs().getString(6));
					resource.setIntro(db.getRs().getString(7));
					resource.setProviderName(db.getRs().getString(8));						
					list_resource.add(resource);						
				}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		return list_resource;	
	}

	@Override
	public boolean addResource(Resource resource) {
		// TODO Auto-generated method stub
		
		boolean flag = false;	//��־λ��false����δ�ɹ�
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = 
				"insert into "
				+"resource(name, type, model, address, phone, intro, providername) "
				+"values('"
				+resource.getName()+"','"
				+resource.getType()+"','"
				+resource.getModel()+"','"
				+resource.getAddress()+"','"
				+resource.getPhone()+"','"
				+resource.getIntro()+"','"
				+resource.getProviderName()+"')";
			if (db.update(sql) > 0) {
				flag = true;	//�������ݿ�ɹ�
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		
		return flag;
	}

	@Override
	public boolean updateResource(Resource resource) {
		// TODO Auto-generated method stub
		
		boolean flag = false;	//��־λ��false����δ�ɹ�
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = 
				"update resource set "
				+"name = '" + resource.getName() + "',"
				+"type = '" + resource.getType() + "',"
				+"model = '" + resource.getModel() + "',"
				+"address = '" + resource.getAddress() + "',"
				+"phone = '" + resource.getPhone() + "',"
				+"intro = '" + resource.getIntro() + "',"
				+"providername = '" + resource.getProviderName() + "'"
				+"where id = '" + resource.getId() + "'";
			if (db.update(sql) > 0) {
				flag = true;	//�޸����ݳɹ�
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		
		return flag;
	}

	@Override
	public boolean deleteResource(Resource resource) {
		// TODO Auto-generated method stub
		
		boolean flag = false;	//��־λ��false����δ�ɹ�
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = 
				"delete from resource where id = '" + resource.getId() + "'";
			if (db.update(sql) > 0) {
				flag = true;	//ɾ�����ݳɹ�
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		
		return flag;
	}

	@Override
	public List<Task> showTask() {
		// TODO Auto-generated method stub
		List<Task> list_task = new ArrayList<Task>();
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = "select * from task ";
			db.query(sql);
			try {
				while (db.next()) {
					Task task = new Task();
					task.setId(db.getRs().getInt(1));
					task.setName(db.getRs().getString(2));
					task.setDemander(db.getRs().getString(3));
					task.setInfo(db.getRs().getString(4));
					task.setType(db.getRs().getString(5));
					task.setFtype(db.getRs().getString(6));
					task.setAddress(db.getRs().getString(7));
					task.setPhone(db.getRs().getString(8));
					task.setEvaluate(db.getRs().getString(9));
					task.setPrice(db.getRs().getInt(10));
					task.setCheckTime(db.getRs().getString(11));
					list_task.add(task);
					
				}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		return list_task;
	}

	@Override
	public List<Order> showOrder(int boss_id) {
		// TODO Auto-generated method stub
List<Order> list_order = new ArrayList<Order>();
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = "select * from `order` where boss_id = '" + boss_id + "'";
			db.query(sql);
			try {
				while (db.next()) {
					Order order = new Order();
					order.setId(db.getRs().getInt(1));
					order.setUser_id(db.getRs().getString(2));
					order.setBoss_id(db.getRs().getString(3));
					order.setP_name(db.getRs().getString(4));
					order.setE_name(db.getRs().getString(5));	
					order.setPrice(db.getRs().getInt(6));
					order.setCreateTime(db.getRs().getString(7));
					order.setPayTime(db.getRs().getString(8));
					list_order.add(order);			
				}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		return list_order;
	}

	@Override
	public boolean upadate(Euser euser, int id) {
		// TODO Auto-generated method stub
		boolean flag = false;	//��־λ��false����δ�ɹ�
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = 
				"update e_user set bossname='"+euser.getBossname()+"', bosspassword='"+euser.getBosspassword()+"', peoplenumber='"+euser.getPeoplenumber()+"', bossusername='"+euser.getBossusername()+
				"', bossphone='"+euser.getBossphone()+"', bossaddress='"+euser.getBossaddress()+"', bossintro='"+euser.getBossintro()+"' where userId='"+id+"'";
			
				
			if (db.update(sql) > 0) {
				flag = true;	//�������ݿ�ɹ�
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		
		return flag;
	}

}
