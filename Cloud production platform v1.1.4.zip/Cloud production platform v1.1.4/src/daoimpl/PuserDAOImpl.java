package daoimpl;

import java.util.*;

import com.dbconn.DBAccess;

import bean.Order;
import bean.Puser;
import bean.Resource;
import bean.Task;
import dao.PuserDAO;

public class PuserDAOImpl implements PuserDAO {

	@Override
	public Puser login(String username, String password) {
		// TODO Auto-generated method stub
		
		Puser puser = new Puser();
		boolean flag = false;	//��־λ��false����δ�ҵ�
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = 
				"select * from p_user where username='"
				+ username + 
				"' and password='"
				+ password + 
				"'";
			db.query(sql);
			if (db.next()) {
				flag = true;	//�ҵ�ƥ����û���������
				try {
					puser.setUserId(db.getRs().getInt(1));
					puser.setUsername(db.getRs().getString(2));
					puser.setPassword(db.getRs().getString(3));
					puser.setName(db.getRs().getString(4));
					puser.setAge(db.getRs().getString(5));
					puser.setSex(db.getRs().getString(6));
					puser.setPhone(db.getRs().getString(7));
					puser.setEmail(db.getRs().getString(8));
				}
				catch(Exception e) {
					e.printStackTrace();
				}
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		
		if(flag == true) {
			return puser;
		}
		else {
			return null;
		}
	}

	@Override
	public boolean register(Puser puser) {
		// TODO Auto-generated method stub
		
		boolean flag = false;	//��־λ��false����δ�ɹ�
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = 
				"insert into "
				+"p_user(username, password, name, age, sex, phone, email) "
				+"values('"
				+puser.getUsername()+"','"
				+puser.getPassword()+"','"
				+puser.getName()+"','"
				+puser.getAge()+"','"
				+puser.getSex()+"','"
				+puser.getPhone()+"','"
				+puser.getEmail()+"')";
			if (db.update(sql) > 0) {
				flag = true;	//�������ݿ�ɹ�
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		
		return flag;
	}

	@Override
	public List<Task> showTask(String username) {
		// TODO Auto-generated method stub
		
		String demander = username;
		
		List<Task> list_task = new ArrayList<Task>();
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = "select * from task where demander = '" + demander + "'";
			db.query(sql);
			try {
				while (db.next()) {
					Task task = new Task();
					task.setId(db.getRs().getInt(1));
					task.setName(db.getRs().getString(2));
					task.setDemander(db.getRs().getString(3));
					task.setInfo(db.getRs().getString(4));
					task.setType(db.getRs().getString(5));
					task.setFtype(db.getRs().getString(6));
					task.setAddress(db.getRs().getString(7));
					task.setPhone(db.getRs().getString(8));
					task.setEvaluate(db.getRs().getString(9));
					task.setPrice(db.getRs().getInt(10));
					task.setCheckTime(db.getRs().getString(11));	
					list_task.add(task);
					
				}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		return list_task;
	}

	@Override
	public boolean addTask(Task task) {
		// TODO Auto-generated method stub
		
		boolean flag = false;	//��־λ��false����δ�ɹ�
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = 
				"insert into "
				+"task(name, demander, info, type, ftype, address, phone, evaluate, price, checktime) "
				+"values('"
				+task.getName()+"','"
				+task.getDemander()+"','"
				+task.getInfo()+"','"
				+task.getType()+"','"
				+task.getFtype()+"','"
				+task.getAddress()+"','"
				+task.getPhone()+"','"
				+task.getEvaluate()+"','"
				+task.getPrice()+"','"
				+"δ���"+"')";
			if (db.update(sql) > 0) {
				flag = true;	//�������ݿ�ɹ�
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		
		return flag;
	}

	@Override
	public boolean updateTask(Task task) {
		// TODO Auto-generated method stub
		
		boolean flag = false;	//��־λ��false����δ�ɹ�
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = 
				"update task set "
				+"name = '" + task.getName() + "',"
				+"demander = '" + task.getDemander() + "',"
				+"info = '" + task.getInfo() + "',"
				+"type = '" + task.getType() + "',"
				+"ftype = '" + task.getFtype() + "',"
				+"address = '" + task.getAddress() + "',"
				+"phone = '" + task.getPhone() + "',"
				+"evaluate = '" + task.getEvaluate() + "',"
				+"price = '" + task.getPrice() + "',"
				+"checktime = '" + task.getCheckTime() + "'"
				+"where id = '" + task.getId() + "'";
			if (db.update(sql) > 0) {
				flag = true;	//�޸����ݳɹ�
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		
		return flag;
	}

	@Override
	public boolean deleteTask(Task task) {
		// TODO Auto-generated method stub
		
		boolean flag = false;	//��־λ��false����δ�ɹ�
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = 
				"delete from task where id = '" + task.getId() + "'";
			if (db.update(sql) > 0) {
				flag = true;	//ɾ�����ݳɹ�
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		
		return flag;
	}

	@Override
	public List<Resource> showResource() {
		List<Resource> list_resource = new ArrayList<Resource>();
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = 
				"select * from resource ";
			db.query(sql);
			try {
				int i=0;
				while (db.next()) {
					Resource resource= new Resource();
					resource.setId(db.getRs().getInt(1));
					resource.setName(db.getRs().getString(2));
					resource.setType(db.getRs().getString(3));
					resource.setModel(db.getRs().getString(4));
					resource.setAddress(db.getRs().getString(5));
					resource.setPhone(db.getRs().getString(6));
					resource.setIntro(db.getRs().getString(7));
					resource.setProviderName(db.getRs().getString(8));						
					list_resource.add(resource);						
				}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		return list_resource;
	}

	@Override
	public List<Order> showOrder(int user_id) {
		// TODO Auto-generated method stub		
		List<Order> list_order = new ArrayList<Order>();
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = "select * from `order` where user_id = '" + user_id + "'";
			db.query(sql);
			try {
				while (db.next()) {
					Order order = new Order();
					order.setId(db.getRs().getInt(1));
					order.setUser_id(db.getRs().getString(2));
					order.setBoss_id(db.getRs().getString(3));
					order.setP_name(db.getRs().getString(4));
					order.setE_name(db.getRs().getString(5));	
					order.setPrice(db.getRs().getInt(6));
					order.setCreateTime(db.getRs().getString(7));
					order.setPayTime(db.getRs().getString(8));
					list_order.add(order);			
				}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		return list_order;
	}

	@Override
	public boolean upadate(Puser puser,int id) {
		// TODO Auto-generated method stub
		boolean flag = false;	//��־λ��false����δ�ɹ�
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = 
				"update p_user set username='"+puser.getUsername()+"', password='"+puser.getPassword()+"', name='"+puser.getName()+"', age='"+puser.getAge()+
				"', sex='"+puser.getSex()+"', phone='"+puser.getPhone()+"', email='"+puser.getEmail()+"' where userId='"+id+"'";
			
				
			if (db.update(sql) > 0) {
				flag = true;	//�������ݿ�ɹ�
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		
		return flag;
	}

}
