package daoimpl;

import java.text.SimpleDateFormat;
import java.util.*;

import com.dbconn.DBAccess;

import bean.Admin;
import bean.Order;
import bean.Resource;
import bean.Task;
import dao.AdminDAO;

public class AdminDAOImpl implements AdminDAO {

	@Override
	public Admin login(String username, String password) {
		// TODO Auto-generated method stub
		
		Admin auser = new Admin();
		boolean flag = false;	//��־λ��false����δ�ҵ�
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = 
				"select * from admin where name='"
				+ username + 
				"' and password='"
				+ password + 
				"'";
			db.query(sql);
			if (db.next()) {
				flag = true;	//�ҵ�ƥ����û���������
				try {
					auser.setId(db.getRs().getInt(1));
					auser.setName(db.getRs().getString(2));
					auser.setPassword(db.getRs().getString(3));
				}
				catch(Exception e) {
					e.printStackTrace();
				}
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		
		if(flag == true) {
			return auser;
		}
		else {
			return null;
		}
	}

	@Override
	public List<Resource> showResource() {
		// TODO Auto-generated method stub
		List<Resource> list_resource = new ArrayList<Resource>();
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = 
				"select * from resource";
			db.query(sql);
			try {
				while (db.next()) {
					Resource resource= new Resource();
					resource.setId(db.getRs().getInt(1));
					resource.setName(db.getRs().getString(2));
					resource.setType(db.getRs().getString(3));
					resource.setModel(db.getRs().getString(4));
					resource.setAddress(db.getRs().getString(5));
					resource.setPhone(db.getRs().getString(6));
					resource.setIntro(db.getRs().getString(7));
					resource.setProviderName(db.getRs().getString(8));						
					list_resource.add(resource);						
				}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		return list_resource;
	}


	@Override
	public boolean checkResource(Resource resource) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Task> showTask() {
		// TODO Auto-generated method stub
	
		List<Task> list_task = new ArrayList<Task>();
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = "select * from task";
			db.query(sql);
			try {
				while (db.next()) {
					Task task = new Task();
					task.setId(db.getRs().getInt(1));
					task.setName(db.getRs().getString(2));
					task.setDemander(db.getRs().getString(3));
					task.setInfo(db.getRs().getString(4));
					task.setType(db.getRs().getString(5));
					task.setFtype(db.getRs().getString(6));
					task.setAddress(db.getRs().getString(7));
					task.setPhone(db.getRs().getString(8));
					task.setEvaluate(db.getRs().getString(9));
					task.setPrice(db.getRs().getInt(10));
					task.setCheckTime(db.getRs().getString(11));
					
					list_task.add(task);
					
				}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		return list_task;
	}

	@Override
	public boolean checkTask(String id, String check) {
		// TODO Auto-generated method stub
		
		boolean flag = false;	//��־λ��false����δ�ɹ�
		
		String checkTime = "";
		
		if (check.equals("1")) {
			//���ͨ��
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			checkTime = sdf.format(new Date());
			checkTime += " ���ͨ��";
		}
		else if (check.equals("2")) {
			//��˲�ͨ��
			checkTime = "����";
		}
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = 
				"update task set "
				+"checktime = '" + checkTime + "'"
				+"where id = '" + id + "'";
			if (db.update(sql) > 0) {
				flag = true;	//�޸����ݳɹ�
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}	
		return flag;
	}

	@Override
	public List<Order> showAllOrder() {
		// TODO Auto-generated method stub
		
		List<Order> list_order = new ArrayList<Order>();
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = "select * from `Order` ";
			db.query(sql);
			try {
				while (db.next()) {
					Order order = new Order();
					order.setId(db.getRs().getInt(1));
					order.setUser_id(db.getRs().getString(2));
					order.setBoss_id(db.getRs().getString(3));
					order.setP_name(db.getRs().getString(4));
					order.setE_name(db.getRs().getString(5));	
					order.setPrice(db.getRs().getInt(6));
					order.setPayTime(db.getRs().getString(7));
					order.setPayTime(db.getRs().getString(8));
					list_order.add(order);			
				}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		return list_order;
	}

	@Override
	public boolean deleteTask(Task task) {
		// TODO Auto-generated method stub
		
		boolean flag = false;	//��־λ��false����δ�ɹ�
		
		//���ݿ��ѯ
		DBAccess db = new DBAccess();
		if (db.createConn() == true) {
			String sql = 
				"delete from task where id = '" + task.getId() + "'";
			if (db.update(sql) > 0) {
				flag = true;	//ɾ�����ݳɹ�
			}
			db.closeRs();
			db.closeStm();
			db.closeConn();
		}
		
		return flag;
	}


}
