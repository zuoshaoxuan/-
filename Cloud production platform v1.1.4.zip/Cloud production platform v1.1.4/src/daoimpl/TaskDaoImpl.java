package daoimpl;

import java.util.ArrayList;
import java.util.List;

import dao.TaskDAO;
import bean.Task;

import com.dbconn.DBAccess;

public class TaskDaoImpl implements TaskDAO {

	@Override
	public List<Task> Showtask(String message) {
		// TODO Auto-generated method stub

		
		List<Task> list_task = new ArrayList<Task>();
			
			//���ݿ��ѯ
			DBAccess db = new DBAccess();
			if (db.createConn() == true) {
				String sql = 
					"select * from task where name like'%"
					+ message + 
					"%' or demander like'%"
					+ message + 
					"%' or info like'%"
					+ message + 
					"%' or type like'%"
					+ message + 
					"%' or ftype like'%"
					+ message + 
					"%' or address like'%"
					+ message + 
					"%' or phone like'%"
					+ message + 
					"%' or evaluate like'%"
					+ message + 
					"%' or price like'"
					+ message + 
					"%' or checktime like'%"
					+ message + 
					"%'";
				db.query(sql);
				try {
					int i=0;
					while (db.next()) {
						Task task= new Task();
						task.setId(db.getRs().getInt(1));
						task.setName(db.getRs().getString(2));
						task.setDemander(db.getRs().getString(3));
						task.setInfo(db.getRs().getString(4));
						task.setType(db.getRs().getString(5));
						task.setFtype(db.getRs().getString(6));
						task.setAddress(db.getRs().getString(7));
						task.setPhone(db.getRs().getString(8));
						task.setEvaluate(db.getRs().getString(9));
						task.setPrice(db.getRs().getInt(10));
						task.setCheckTime(db.getRs().getString(11));						
						list_task.add(task);						
					}
				}
				catch(Exception e) {
					e.printStackTrace();
				}
				db.closeRs();
				db.closeStm();
				db.closeConn();
			}
			return list_task;
		}

			
		
	

}
