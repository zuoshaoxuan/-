package bean;

public class Euser {
	
	//��ҵ�û�
	//��Ӧ���ݿ��e_user��
	
	private String userType = "2";	//�û�����
	private int userId;				//�û�ID
	private String bossname;		//��ҵ����
	private String bosslist;		//��ҵ����
	private String peoplenumber;	//��Ա��ģ
	private String yyfilename;		//Ӫҵִ��
	private String sfzfilename;		//��������֤
	private String bossusername;	//��˾�û���
	private String bosspassword;	//����
	private String bossphone;		//��ϵ�绰
	private String bossaddress;		//��˾��ַ
	private String bossintro;		//��˾���
	
	public String getBossusername() {
		return bossusername;
	}
	public void setBossusername(String bossusername) {
		this.bossusername = bossusername;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getBossname() {
		return bossname;
	}
	public void setBossname(String bossname) {
		this.bossname = bossname;
	}
	public String getBosslist() {
		return bosslist;
	}
	public void setBosslist(String bosslist) {
		this.bosslist = bosslist;
	}
	public String getPeoplenumber() {
		return peoplenumber;
	}
	public void setPeoplenumber(String peoplenumber) {
		this.peoplenumber = peoplenumber;
	}
	public String getYyfilename() {
		return yyfilename;
	}
	public void setYyfilename(String yyfilename) {
		this.yyfilename = yyfilename;
	}
	public String getSfzfilename() {
		return sfzfilename;
	}
	public void setSfzfilename(String sfzfilename) {
		this.sfzfilename = sfzfilename;
	}
	public String getBosspassword() {
		return bosspassword;
	}
	public void setBosspassword(String bosspassword) {
		this.bosspassword = bosspassword;
	}
	public String getBossphone() {
		return bossphone;
	}
	public void setBossphone(String bossphone) {
		this.bossphone = bossphone;
	}
	public String getBossaddress() {
		return bossaddress;
	}
	public void setBossaddress(String bossaddress) {
		this.bossaddress = bossaddress;
	}
	public String getBossintro() {
		return bossintro;
	}
	public void setBossintro(String bossintro) {
		this.bossintro = bossintro;
	}
	
}
