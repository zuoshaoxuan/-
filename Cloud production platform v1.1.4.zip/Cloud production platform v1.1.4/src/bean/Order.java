package bean;

import java.util.Date;

public class Order {
	
	//����
	//��Ӧ���ݿ��order��
	
	private int id;				//����ID
	private String user_id;
	private String boss_id;	
	private String p_name;	
	private String e_name;//�û�ID
	private int price;
	public String getBoss_id() {
		return boss_id;
	}
	public void setBoss_id(String boss_id) {
		this.boss_id = boss_id;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getE_name() {
		return e_name;
	}
	public void setE_name(String e_name) {
		this.e_name = e_name;
	}
	private String createTime;	//����ʱ��
	private String payTime;		//֧��ʱ��
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public String getPayTime() {
		return payTime;
	}
	public void setPayTime(String payTime) {
		this.payTime = payTime;
	}

	
}
